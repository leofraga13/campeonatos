import Link from 'next/link';

export default function Home() {
  return (
    <div>
      {/* Navbar */}
      <nav style={{ display: 'flex', justifyContent: 'space-around', padding: '1rem 0', borderBottom: '1px solid #ccc' }}>
      <div>LOGO</div>
        <Link href="/brasileirao">BRASILEIRÃO</Link>
        <Link href="/copa">COPA DO BRASIL</Link>
        <Link href="/libertadores">lIBERTADORES</Link>
        <Link href="/champions">CHAMPIONS LEAGUE</Link>
      </nav>

      {/* Cards */}
      <main style={{ display: 'flex', justifyContent: 'space-around', padding: '2rem' }}>
        <section style={{ border: '1px solid #ccc', padding: '1rem', borderRadius: '8px', maxWidth: '250px' }}>
          <h2>Brasileirão</h2>
          <p>
          O Brasileirão é a principal liga de futebol do Brasil, disputada desde 1971 (com unificação de títulos anteriores). Vinte clubes jogam em pontos corridos, turno e returno. O regulamento de 2025 mantém esse formato, com critérios de desempate definidos. Os quatro primeiros vão para a Libertadores e os quatro últimos são rebaixados. O Palmeiras é o maior campeão, seguido por Santos e Flamengo. O campeonato é crucial para definir os representantes brasileiros em competições continentais.
          </p>
        </section>

        <section style={{ border: '1px solid #ccc', padding: '1rem', borderRadius: '8px', maxWidth: '250px' }}>
          <h2>Libertadores</h2>
          <p>
          Libertadores é o principal torneio de clubes da América do Sul, organizado pela CONMEBOL desde 1960. Quarenta e sete equipes participam, com fases preliminares, grupos (ida e volta), oitavas, quartas, semifinais e final em jogo único desde 2019. O campeão vai para o Mundial de Clubes e disputa a Recopa. A fase de grupos de 2025 começou em abril, com a final em 29 de novembro. O Independiente (Argentina) é o maior campeão (7 títulos), e o Brasil é o país com mais títulos (24) e clubes campeões (12). É um torneio de grande prestígio e rivalidade.
          </p>
        </section>

        <section style={{ border: '1px solid #ccc', padding: '1rem', borderRadius: '8px', maxWidth: '250px' }}>
          <h2>Copa do Brasil</h2>
          <p>
          A Copa do Brasil é um torneio mata-mata nacional com 92 times de todas as divisões, desde 1989. O campeão vai direto para a Libertadores e Supercopa. As duas primeiras fases são jogo único com vantagem do empate para o melhor ranqueado (visitante). Da terceira fase em diante, são jogos de ida e volta, com pênaltis em caso de empate agregado. Doze times da Libertadores entram na terceira fase. A edição de 2025 está na terceira fase (ida em abril), com a final em novembro. Cruzeiro é o maior campeão (6 títulos), e a competição é conhecida por zebras, com três campeões de divisões inferiores.
          </p>
        </section>

        <section style={{ border: '1px solid #ccc', padding: '1rem', borderRadius: '8px', maxWidth: '250px' }}>
          <h2>Champions League</h2>
          <p>
          Champions League é o principal torneio de clubes da Europa, organizado pela UEFA desde 1955. Desde 2024-25, tem um formato de liga com 36 times jogando 8 jogos cada. Os 8 melhores vão direto para as oitavas, e do 9º ao 24º disputam um play-off. As fases eliminatórias são ida e volta, e a final é única. A final de 2025 será em Munique. O Real Madrid é o maior campeão (15 títulos). É um torneio de alto nível e muito assistido.
          </p>
        </section>

      </main>
    </div>
  );
}
