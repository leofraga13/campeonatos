'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';

export default function BrasileiraoPage() {
  const [tabela, setTabela] = useState([]);
  const [carregando, setCarregando] = useState(true);

  useEffect(() => {
    const fetchTabela = async () => {
      try {
        const response = await fetch('https://api.api-futebol.com.br/v1/campeonatos/10/tabela', {
          headers: {
            Authorization: 'Bearer test_d669ab27a3819608318d1439cccfbf' 
          }
        });

        const data = await response.json();
        console.log('Resposta da API:', data);
        setTabela(data);
      } catch (error) {
        console.error('Erro ao buscar tabela:', error);
        setTabela(null);
      } finally {
        setCarregando(false);
      }
    };

    fetchTabela();
  }, []);

  return (
    <div>
      {/* Navbar */}
      <nav style={{ display: 'flex', justifyContent: 'space-around', padding: '1rem 0', borderBottom: '1px solid #ccc' }}>
      <Link href="/">LOGO</Link>
        <Link href="/brasileirao">BRASILEIRÃO</Link>
        <Link href="/copa">COPA DO BRASIL</Link>
        <Link href="/libertadores">LIBERTADORES</Link>
        <Link href="/champions">CHAMPIONS LEAGUE</Link>
      </nav>

      {/* Conteúdo da página */}
      <main style={{ padding: '2rem' }}>
        <h1>Brasileirão</h1>
        
        <h2 style={{ marginTop: '2rem' }}>Tabela do Campeonato Brasileiro</h2>

        {carregando ? (
          <p>Carregando tabela...</p>
        ) : Array.isArray(tabela) ? (
          <table border="1" cellPadding="6" style={{ borderCollapse: 'collapse', width: '100%' }}>
            <thead>
              <tr>
                <th>Posição</th>
                <th>Time</th>
                <th>Pontos</th>
                <th>Jogos</th>
                <th>Vitórias</th>
                <th>Empates</th>
                <th>Derrotas</th>
                <th>Gols Pró</th>
                <th>Gols Contra</th>
                <th>Saldo</th>
                <th>Aproveitamento</th>
                <th>Últimos Jogos</th>
              </tr>
            </thead>
            <tbody>
              {tabela.map((time) => (
                <tr key={time.time.time_id}>
                  <td>{time.posicao}</td>
                  <td>
                    <img
                      src={time.time.escudo}
                      alt={time.time.nome_popular}
                      width="20"
                      style={{ verticalAlign: 'middle', marginRight: '8px' }}
                    />
                    {time.time.nome_popular}
                  </td>
                  <td>{time.pontos}</td>
                  <td>{time.jogos}</td>
                  <td>{time.vitorias}</td>
                  <td>{time.empates}</td>
                  <td>{time.derrotas}</td>
                  <td>{time.gols_pro}</td>
                  <td>{time.gols_contra}</td>
                  <td>{time.saldo_gols}</td>
                  <td>{time.aproveitamento}%</td>
                  <td>{time.ultimos_jogos.join(' ')}</td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <p>Erro ao carregar a tabela.</p>
        )}
      </main>
    </div>
  );
}
