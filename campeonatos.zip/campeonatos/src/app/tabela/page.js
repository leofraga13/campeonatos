'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';

export default function BrasileiraoPage() {
  const [tabela, setTabela] = useState([]);
  const [carregando, setCarregando] = useState(true);

  const thStyle = {
    padding: '10px',
    borderBottom: '2px solid #555',
    backgroundColor: '#111',
    color: '#fff',
    textAlign: 'left',
  };

  const tdStyle = {
    padding: '8px',
    verticalAlign: 'middle',
    textAlign: 'left',
    color: '#fff',
  };

  useEffect(() => {
    const fetchTabela = async () => {
      try {
        const response = await fetch('https://api.api-futebol.com.br/v1/campeonatos/10/tabela', {
          headers: {
            Authorization: 'Bearer test_d669ab27a3819608318d1439cccfbf',
          },
        });

        const data = await response.json();
        setTabela(data);
      } catch (error) {
        console.error('Erro ao buscar tabela:', error);
        setTabela(null);
      } finally {
        setCarregando(false);
      }
    };

    fetchTabela();
  }, []);

  return (
    <div style={{ backgroundColor: '#000', minHeight: '100vh', color: '#fff' }}>
      {/* Navbar */}
      <nav
        style={{
          display: 'flex',
          justifyContent: 'space-around',
          padding: '1rem 0',
          borderBottom: '1px solid #555',
          flexWrap: 'wrap',
          backgroundColor: '#111',
        }}
      >
        <Link href="/" style={{ color: '#fff', textDecoration: 'none' }}>MENU</Link>
        <Link href="/brasileirao" style={{ color: '#fff', textDecoration: 'none' }}>BRASILEIRÃO B</Link>
        <Link href="/tabela" style={{ color: '#fff', textDecoration: 'none' }}>TABELA</Link>
        <Link href="/artilharia" style={{ color: '#fff', textDecoration: 'none' }}>ARTILHARIA</Link>
      </nav>

      {/* Conteúdo */}
      <main style={{ padding: '2rem' }}>
        <h1 className="text-3xl font-bold mb-4">Tabela Brasileirão Série B</h1>

        {carregando ? (
          <p>Carregando tabela...</p>
        ) : Array.isArray(tabela) ? (
          <div style={{ overflowX: 'auto' }}>
            <table
              style={{
                width: '100%',
                borderCollapse: 'collapse',
                fontFamily: 'Arial, sans-serif',
                backgroundColor: '#000',
              }}
            >
              <thead>
                <tr>
                  <th style={thStyle}>Posição</th>
                  <th style={thStyle}>Time</th>
                  <th style={thStyle}>Pontos</th>
                  <th style={thStyle}>Jogos</th>
                  <th style={thStyle}>Vitórias</th>
                  <th style={thStyle}>Empates</th>
                  <th style={thStyle}>Derrotas</th>
                  <th style={thStyle}>Gols Pró</th>
                  <th style={thStyle}>Gols Contra</th>
                  <th style={thStyle}>Saldo</th>
                  <th style={thStyle}>Aproveitamento</th>
                  <th style={thStyle}>Últimos Jogos</th>
                </tr>
              </thead>
              <tbody>
                {tabela.map((time, index) => (
                  <tr
                    key={time.time.time_id}
                    style={{
                      backgroundColor: index % 2 === 0 ? '#111' : '#1a1a1a',
                      borderBottom: '1px solid #333',
                    }}
                  >
                    <td style={tdStyle}>{time.posicao}</td>
                    <td style={tdStyle}>
                      <img
                        src={time.time.escudo}
                        alt={time.time.nome_popular}
                        width="20"
                        style={{ verticalAlign: 'middle', marginRight: '8px' }}
                      />
                      {time.time.nome_popular}
                    </td>
                    <td style={tdStyle}>{time.pontos}</td>
                    <td style={tdStyle}>{time.jogos}</td>
                    <td style={tdStyle}>{time.vitorias}</td>
                    <td style={tdStyle}>{time.empates}</td>
                    <td style={tdStyle}>{time.derrotas}</td>
                    <td style={tdStyle}>{time.gols_pro}</td>
                    <td style={tdStyle}>{time.gols_contra}</td>
                    <td style={tdStyle}>{time.saldo_gols}</td>
                    <td style={tdStyle}>{time.aproveitamento}%</td>
                    <td style={tdStyle}>{time.ultimos_jogos.join(' ')}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p>Erro ao carregar a tabela.</p>
        )}
      </main>
    </div>
  );
}
