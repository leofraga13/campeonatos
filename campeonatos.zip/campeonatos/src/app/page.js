import Link from 'next/link';

export default function Home() {
  const cardStyle = {
    border: '1px solid #ccc',
    padding: '1rem',
    borderRadius: '8px',
    maxWidth: '400px',
    margin: '1rem',
    flex: '1 1 400px',
  };

  const titleStyle = {
  fontWeight: 'bold',
  marginBottom: '0.5rem',
};


  return (
    <section>
      {/* Navbar */}
      <nav
        style={{
          display: 'flex',
          justifyContent: 'space-around',
          padding: '1rem 0',
          borderBottom: '1px solid #ccc', flexWrap: 'wrap', 
        }}
      >
        <section >MENU</section>
        <Link href="/brasileirao">BRASILEIRÃO B</Link>
        <Link href="/tabela">TABELA</Link>
        <Link href="/artilharia">ARTILHARIA</Link>
        
      </nav>

      {/* Cards */}
      <main
        style={{
          display: 'flex',
          justifyContent: 'space-around',
          padding: '2rem',
          flexWrap: 'wrap', 
        }}
      >
        <section style={cardStyle}>
          <h2 style={titleStyle}>Formato</h2>
          <p>
            O campeonato teve sua primeira edição em 1971, coroando o Villa Nova como seu campeão inaugural. Nos primeiros anos, a competição sofreu com a falta de padronização, apresentando diversos formatos e interrupções ao longo da década de 70 e início dos anos 80. Períodos como 1973 a 1979 e os anos de 1986, 1987, 1993 e 2000 não viram a realização de uma Série B contínua, com a criação de torneios paralelos ou módulos da Copa União.

          </p>
          <p>      
            <br />A partir de 1988, a competição ganhou mais regularidade, embora ainda com variações nos sistemas de disputa. O grande marco para a estabilidade e o reconhecimento da Série B veio em 2006, quando foi adotado o formato de pontos corridos. Esse modelo, com turno e returno, trouxe maior justiça e previsibilidade ao torneio, que hoje conta com 20 equipes. As quatro melhores sobem para a Série A, enquanto as quatro últimas são rebaixadas para a Série C.
          </p>
        </section>

        <section style={cardStyle}>
          <h2 style={titleStyle}>Destaques e Curiosidades</h2>
          <p>
          Ao longo de sua trajetória, a Série B já viu 35 clubes diferentes levantarem a taça, demonstrando a competitividade da divisão. Clubes como América-MG, Botafogo, Coritiba, Goiás, Palmeiras, Paysandu e Red Bull Bragantino dividem o posto de maiores campeões, com dois títulos cada. O Cruzeiro, em 2022, não só conquistou o título, mas também estabeleceu o recorde de campeão com maior antecedência na história da competição. <br /><br />Já o Corinthians, em 2008, protagonizou a melhor campanha na era dos pontos corridos, somando 85 pontos e um impressionante aproveitamento de 74%.          
          </p>
        </section>

        <section style={cardStyle}>
          <h2 style={titleStyle}>Maiores Artilheiros</h2>
          <p>
            O recorde de maior número de gols marcados por um jogador em uma única edição da Série B do Campeonato Brasileiro pertence a Bruno Rangel, que anotou 31 gols pela Chapecoense na temporada de 2013. 
          </p>
          <p><br />Abaixo, seguem os cinco maiores artilheiros em uma única edição da Série B:<br /></p>
          <p><br />
            1- Bruno Rangel – 31 gols (Chapecoense, 2013)<br />
            2- Zé Carlos – 27 gols (Criciúma, 2012)<br />
            3- Alessandro – 25 gols (Ipatinga, 2007)<br />
            4- Uéslei – 25 gols (Bahia, 1999)<br />
            5- Túlio Maravilha – 24 gols (Vila Nova, 2008)
          </p>
        </section>
      </main>
    </section>
  );
}
