'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';

export default function BrasileiraoPagePage() {
  const [campeonato, setCampeonato] = useState(null);

  useEffect(() => {
    const fetchDados = async () => {
      try {
        const res = await fetch('https://api.api-futebol.com.br/v1/campeonatos/10', {
          headers: {
            Authorization: 'Bearer test_d669ab27a3819608318d1439cccfbf'
          }
        });
        const data = await res.json();
        setCampeonato(data);
      } catch (err) {
        console.error('Erro ao buscar dados da Copa do Brasil:', err);
      }
    };

    fetchDados();
  }, []);
 
  return(
    <div>
      {/* Navbar */}
      <nav style={{ display: 'flex', justifyContent: 'space-around', padding: '1rem 0', borderBottom: '1px solid #ccc', flexWrap: 'wrap' }}>
        <Link href="/">MENU</Link>
        <Link href="/brasileirao">BRASILEIRÃO B</Link>
        <Link href="/tabela">TABELA</Link>
        <Link href="/artilharia">ARTILHARIA</Link>
      </nav>

      {/* Conteúdo */}
      <main className="p-6 max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-4">Brasileirão Série B</h1>
        <p className="text-gray-400 mb-8">Informações sobre o a segunda divisão nacional.</p>

        {campeonato ? (
          <div className="bg-gray-900 p-4 rounded-lg shadow mb-8">
            <div className="flex flex-col sm:flex-row items-center gap-4">
              <img src={campeonato.logo} alt="Logo campeonato" className="h-20 w-auto" />
              <div>
                <h2 className="text-xl font-semibold">{campeonato.nome_popular}</h2>
                <p className="text-gray-400">Edição: {campeonato.edicao_atual?.nome_popular}</p>
                <p className="text-gray-400">Fase Atual: {campeonato.fase_atual?.nome}</p>
                <p className="text-gray-400">Tipo: {campeonato.tipo}</p>
                <p className="text-gray-400">Status: {campeonato.status}</p>
              </div>
            </div>
          </div>
        ) : (
          <p>Carregando dados do Brasileirão Série B...</p>
        )}
      </main>
    </div>
  );
}
