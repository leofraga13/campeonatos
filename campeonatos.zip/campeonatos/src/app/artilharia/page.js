'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';

export default function ArtilhariaPage() {
  const [artilheiros, setArtilheiros] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchArtilharia = async () => {
      try {
        const response = await fetch('https://api.api-futebol.com.br/v1/campeonatos/10/artilharia', {
          headers: {
            Authorization: 'Bearer test_d669ab27a3819608318d1439cccfbf'
          }
        });
        const data = await response.json();
        console.log(data); 
        setArtilheiros(data.filter(item => item !== null)); 
      } catch (error) {
        console.error('Erro ao buscar artilharia:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchArtilharia();
  }, []);
  return(
    <div>
      {/* Navbar */}
      <nav style={{ display: 'flex', justifyContent: 'space-around', padding: '1rem 0', borderBottom: '1px solid #ccc', flexWrap: 'wrap' }}>
        <Link href="/">MENU</Link>
        <Link href="/brasileirao">BRASILEIRÃO B</Link>
        <Link href="/tabela">TABELA</Link>
        <Link href="/artilharia">ARTILHARIA</Link>
      </nav>

      {/* Conteúdo da página */}
      <div className="mt-10">
      <h2 className="text-2xl font-semibold mb-4">Artilharia</h2>

      {loading ? (
        <p>Carregando artilheiros...</p>
      ) : artilheiros.length === 0 ? (
        <p className="text-gray-400">Nenhum artilheiro disponível no momento.</p>
      ) : (
        <ul className="space-y-2">
          {artilheiros.map((jogador, index) => (
            <li key={index} className="bg-gray-900 p-4 rounded-lg flex items-center justify-between">
              <div>
                <p className="text-lg font-medium">{jogador.atleta.nome_popular}</p>
                <p className="text-sm text-gray-400">{jogador.time.nome_popular}</p>
              </div>
              <span className="text-xl font-bold">{jogador.gols}</span>
            </li>
          ))}
        </ul>
      )}
    </div>    
  </div>
  );
}
